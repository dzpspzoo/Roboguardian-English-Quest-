# AEGIS-7 v2 – figurka 30 cm z renderu (Tripo), 11 części + kołki

Drukarka: Anycubic Kobra S1 + ACE 2 Pro. Program: Anycubic Slicer Next.

## Sloty ACE 2 Pro
| Slot | Filament | Gdzie |
|------|----------|-------|
| 1 | granatowy / bardzo ciemny niebieski (może być czarny) | korpus, stawy |
| 2 | pomarańczowy | pancerz |
| 3 | srebrny / jasnoszary | płyty na hełmie i barkach |
| 4 | turkus (najlepiej przezroczysty lub „silk”) | pierś, wizjer |

Pliki **.3mf** mają już pomalowane kolory (sprawdzone w Slicer Next: kolory zostają po wczytaniu).
Po otwarciu wystarczy przypisać filamenty do slotów 1–4. Kto drukuje w jednym kolorze, bierze **_jeden_kolor.stl**.

## Najpierw test luzu
`00_test_luzu` + jeden kołek z `00_kolki`. Domyślny otwór to 8,3 mm (3 kreski). Jeśli pasuje inny, Claude przelicza wszystko jeszcze raz.

## Ustawienia druku (PLA)
Warstwa 0,16–0,2 mm, 3 obrysy, wypełnienie 15%, **podpory automatyczne typu drzewo** (model ma dużo wystających detali).
Części są ułożone płaską powierzchnią cięcia na stole. Kołki leżą płasko.

## Kolejność nagród za misje
| Nr | Część | Kołek do |
|----|-------|----------|
| 1 | 01_tulow (tułów ze świecącą piersią) | – (baza) |
| 2 | 02_glowa | tułowia (pionowo) |
| 3 | 03_miednica | tułowia (pionowo) |
| 4–5 | 04_udo_L, 05_udo_P | miednicy (z boku) |
| 6–7 | 06_golen_L, 07_golen_P (ze stopami) | uda (pionowo) |
| 8–9 | 08_ramie_L, 09_przedramie_L | tułowia z boku / ramienia pionowo |
| 10–11 | 10_ramie_P, 11_przedramie_P | jw. |

L = lewa strona robota (patrząc od tyłu robota).

## Składanie (bez kleju)
1. Uda wsuń kołkami z boku w miednicę.
2. Miednicę z udami wsuń od dołu w tułów.
3. Golenie wsuń od dołu w uda.
4. Głowę wciśnij od góry, ramiona z boku w barki, przedramiona od dołu w ramiona.
Każda część wsuwa się na jeden kołek 8 mm × 21 mm, zawsze w jednej osi, więc nic się nie klinuje.

## Pliki
- `AEGIS-7_v2_przod.png`, `_3-4.png`, `_rozstrzelony.png` – podglądy (kolory = filamenty).
- `raport.txt` – wymiary, objętości, szczelność siatek (wszystkie 0 błędów), lista kołków.
- `AEGIS-7_v2_czesci.blend` – części w Blenderze.
- Generator: `..\skrypty\v2_kolory.py` (kolory z tekstury) i `..\skrypty\v2_ciecie.py` (cięcie, kołki, eksport).

Dalsze nagrody (tarcza, miecz, silniki, skrzydła, podstawka) można wygenerować w Tripo osobno i dodać tym samym sposobem.
